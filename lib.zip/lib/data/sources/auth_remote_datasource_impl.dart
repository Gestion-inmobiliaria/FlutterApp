import 'dart:convert';
import 'package:http/http.dart' as http;
import 'auth_remote_datasource.dart';

// La clase `AuthRemoteDataSourceImpl` implementa la interfaz `AuthRemoteDataSource`.
// Su objetivo es realizar las operaciones de autenticación directamente con una API remota.

class AuthRemoteDataSourceImpl implements AuthRemoteDataSource {
  // Cliente HTTP utilizado para realizar las solicitudes a la API.
  final http.Client client;

  // Constructor que recibe una instancia de `http.Client`.
  // Esto permite inyectar un cliente HTTP, facilitando pruebas y mantenimiento.
  AuthRemoteDataSourceImpl({required this.client});

  @override
  // Método para iniciar sesión.
  // Este método realiza una solicitud POST a la API con las credenciales del usuario.
  Future<String> login(String email, String password) async {
    // Realiza una solicitud POST a la URL de inicio de sesión.
    final response = await client.post(
      Uri.parse('http://localhost:3000/api/auth/login'), // URL de la API.
      headers: {
        'Content-Type': 'application/json',
      }, // Cabeceras de la solicitud.
      body: jsonEncode({
        'email': email,
        'password': password,
      }), // Cuerpo de la solicitud en formato JSON.
    );

    // Verifica si la respuesta tiene un código de estado exitoso (200 o 201).
    if (response.statusCode == 200 || response.statusCode == 201) {
      // Decodifica el cuerpo de la respuesta JSON.
      final body = jsonDecode(response.body);
      // Extrae el token de acceso de la respuesta.
      final token = body['data']['accessToken'];
      return token; // Devuelve el token.
    } else {
      // Lanza una excepción si la solicitud falla.
      throw Exception('Error al iniciar sesión');
    }
  }
}
