import 'package:flutter/material.dart';

class AppColors {
  static const primary = Color.fromARGB(255, 232, 0, 0);
  static const lightbackground = Color.fromARGB(255, 255, 255, 255);
  static const darkbackground = Color.fromARGB(255, 0, 0, 0);
}
